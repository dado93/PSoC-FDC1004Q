/*******************************************************************************
* File Name: MultiCmdTimer_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "MultiCmdTimer.h"

static MultiCmdTimer_backupStruct MultiCmdTimer_backup;


/*******************************************************************************
* Function Name: MultiCmdTimer_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MultiCmdTimer_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void MultiCmdTimer_SaveConfig(void) 
{
    #if (!MultiCmdTimer_UsingFixedFunction)
        MultiCmdTimer_backup.TimerUdb = MultiCmdTimer_ReadCounter();
        MultiCmdTimer_backup.InterruptMaskValue = MultiCmdTimer_STATUS_MASK;
        #if (MultiCmdTimer_UsingHWCaptureCounter)
            MultiCmdTimer_backup.TimerCaptureCounter = MultiCmdTimer_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!MultiCmdTimer_UDB_CONTROL_REG_REMOVED)
            MultiCmdTimer_backup.TimerControlRegister = MultiCmdTimer_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: MultiCmdTimer_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MultiCmdTimer_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void MultiCmdTimer_RestoreConfig(void) 
{   
    #if (!MultiCmdTimer_UsingFixedFunction)

        MultiCmdTimer_WriteCounter(MultiCmdTimer_backup.TimerUdb);
        MultiCmdTimer_STATUS_MASK =MultiCmdTimer_backup.InterruptMaskValue;
        #if (MultiCmdTimer_UsingHWCaptureCounter)
            MultiCmdTimer_SetCaptureCount(MultiCmdTimer_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!MultiCmdTimer_UDB_CONTROL_REG_REMOVED)
            MultiCmdTimer_WriteControlRegister(MultiCmdTimer_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: MultiCmdTimer_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MultiCmdTimer_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void MultiCmdTimer_Sleep(void) 
{
    #if(!MultiCmdTimer_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(MultiCmdTimer_CTRL_ENABLE == (MultiCmdTimer_CONTROL & MultiCmdTimer_CTRL_ENABLE))
        {
            /* Timer is enabled */
            MultiCmdTimer_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            MultiCmdTimer_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    MultiCmdTimer_Stop();
    MultiCmdTimer_SaveConfig();
}


/*******************************************************************************
* Function Name: MultiCmdTimer_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MultiCmdTimer_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void MultiCmdTimer_Wakeup(void) 
{
    MultiCmdTimer_RestoreConfig();
    #if(!MultiCmdTimer_UDB_CONTROL_REG_REMOVED)
        if(MultiCmdTimer_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                MultiCmdTimer_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
