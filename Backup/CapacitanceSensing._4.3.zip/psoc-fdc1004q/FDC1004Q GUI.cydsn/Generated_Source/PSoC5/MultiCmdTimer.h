/*******************************************************************************
* File Name: MultiCmdTimer.h
* Version 2.80
*
*  Description:
*     Contains the function prototypes and constants available to the timer
*     user module.
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_TIMER_MultiCmdTimer_H)
#define CY_TIMER_MultiCmdTimer_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

extern uint8 MultiCmdTimer_initVar;

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component Timer_v2_80 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */


/**************************************
*           Parameter Defaults
**************************************/

#define MultiCmdTimer_Resolution                 8u
#define MultiCmdTimer_UsingFixedFunction         1u
#define MultiCmdTimer_UsingHWCaptureCounter      0u
#define MultiCmdTimer_SoftwareCaptureMode        0u
#define MultiCmdTimer_SoftwareTriggerMode        0u
#define MultiCmdTimer_UsingHWEnable              0u
#define MultiCmdTimer_EnableTriggerMode          0u
#define MultiCmdTimer_InterruptOnCaptureCount    0u
#define MultiCmdTimer_RunModeUsed                0u
#define MultiCmdTimer_ControlRegRemoved          0u

#if defined(MultiCmdTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG)
    #define MultiCmdTimer_UDB_CONTROL_REG_REMOVED            (0u)
#elif  (MultiCmdTimer_UsingFixedFunction)
    #define MultiCmdTimer_UDB_CONTROL_REG_REMOVED            (0u)
#else 
    #define MultiCmdTimer_UDB_CONTROL_REG_REMOVED            (1u)
#endif /* End MultiCmdTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG */


/***************************************
*       Type defines
***************************************/


/**************************************************************************
 * Sleep Wakeup Backup structure for Timer Component
 *************************************************************************/
typedef struct
{
    uint8 TimerEnableState;
    #if(!MultiCmdTimer_UsingFixedFunction)

        uint8 TimerUdb;
        uint8 InterruptMaskValue;
        #if (MultiCmdTimer_UsingHWCaptureCounter)
            uint8 TimerCaptureCounter;
        #endif /* variable declarations for backing up non retention registers in CY_UDB_V1 */

        #if (!MultiCmdTimer_UDB_CONTROL_REG_REMOVED)
            uint8 TimerControlRegister;
        #endif /* variable declaration for backing up enable state of the Timer */
    #endif /* define backup variables only for UDB implementation. Fixed function registers are all retention */

}MultiCmdTimer_backupStruct;


/***************************************
*       Function Prototypes
***************************************/

void    MultiCmdTimer_Start(void) ;
void    MultiCmdTimer_Stop(void) ;

void    MultiCmdTimer_SetInterruptMode(uint8 interruptMode) ;
uint8   MultiCmdTimer_ReadStatusRegister(void) ;
/* Deprecated function. Do not use this in future. Retained for backward compatibility */
#define MultiCmdTimer_GetInterruptSource() MultiCmdTimer_ReadStatusRegister()

#if(!MultiCmdTimer_UDB_CONTROL_REG_REMOVED)
    uint8   MultiCmdTimer_ReadControlRegister(void) ;
    void    MultiCmdTimer_WriteControlRegister(uint8 control) ;
#endif /* (!MultiCmdTimer_UDB_CONTROL_REG_REMOVED) */

uint8  MultiCmdTimer_ReadPeriod(void) ;
void    MultiCmdTimer_WritePeriod(uint8 period) ;
uint8  MultiCmdTimer_ReadCounter(void) ;
void    MultiCmdTimer_WriteCounter(uint8 counter) ;
uint8  MultiCmdTimer_ReadCapture(void) ;
void    MultiCmdTimer_SoftwareCapture(void) ;

#if(!MultiCmdTimer_UsingFixedFunction) /* UDB Prototypes */
    #if (MultiCmdTimer_SoftwareCaptureMode)
        void    MultiCmdTimer_SetCaptureMode(uint8 captureMode) ;
    #endif /* (!MultiCmdTimer_UsingFixedFunction) */

    #if (MultiCmdTimer_SoftwareTriggerMode)
        void    MultiCmdTimer_SetTriggerMode(uint8 triggerMode) ;
    #endif /* (MultiCmdTimer_SoftwareTriggerMode) */

    #if (MultiCmdTimer_EnableTriggerMode)
        void    MultiCmdTimer_EnableTrigger(void) ;
        void    MultiCmdTimer_DisableTrigger(void) ;
    #endif /* (MultiCmdTimer_EnableTriggerMode) */


    #if(MultiCmdTimer_InterruptOnCaptureCount)
        void    MultiCmdTimer_SetInterruptCount(uint8 interruptCount) ;
    #endif /* (MultiCmdTimer_InterruptOnCaptureCount) */

    #if (MultiCmdTimer_UsingHWCaptureCounter)
        void    MultiCmdTimer_SetCaptureCount(uint8 captureCount) ;
        uint8   MultiCmdTimer_ReadCaptureCount(void) ;
    #endif /* (MultiCmdTimer_UsingHWCaptureCounter) */

    void MultiCmdTimer_ClearFIFO(void) ;
#endif /* UDB Prototypes */

/* Sleep Retention APIs */
void MultiCmdTimer_Init(void)          ;
void MultiCmdTimer_Enable(void)        ;
void MultiCmdTimer_SaveConfig(void)    ;
void MultiCmdTimer_RestoreConfig(void) ;
void MultiCmdTimer_Sleep(void)         ;
void MultiCmdTimer_Wakeup(void)        ;


/***************************************
*   Enumerated Types and Parameters
***************************************/

/* Enumerated Type B_Timer__CaptureModes, Used in Capture Mode */
#define MultiCmdTimer__B_TIMER__CM_NONE 0
#define MultiCmdTimer__B_TIMER__CM_RISINGEDGE 1
#define MultiCmdTimer__B_TIMER__CM_FALLINGEDGE 2
#define MultiCmdTimer__B_TIMER__CM_EITHEREDGE 3
#define MultiCmdTimer__B_TIMER__CM_SOFTWARE 4



/* Enumerated Type B_Timer__TriggerModes, Used in Trigger Mode */
#define MultiCmdTimer__B_TIMER__TM_NONE 0x00u
#define MultiCmdTimer__B_TIMER__TM_RISINGEDGE 0x04u
#define MultiCmdTimer__B_TIMER__TM_FALLINGEDGE 0x08u
#define MultiCmdTimer__B_TIMER__TM_EITHEREDGE 0x0Cu
#define MultiCmdTimer__B_TIMER__TM_SOFTWARE 0x10u


/***************************************
*    Initialial Parameter Constants
***************************************/

#define MultiCmdTimer_INIT_PERIOD             99u
#define MultiCmdTimer_INIT_CAPTURE_MODE       ((uint8)((uint8)1u << MultiCmdTimer_CTRL_CAP_MODE_SHIFT))
#define MultiCmdTimer_INIT_TRIGGER_MODE       ((uint8)((uint8)0u << MultiCmdTimer_CTRL_TRIG_MODE_SHIFT))
#if (MultiCmdTimer_UsingFixedFunction)
    #define MultiCmdTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)0u << MultiCmdTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                  ((uint8)((uint8)0 << MultiCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT)))
#else
    #define MultiCmdTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)0u << MultiCmdTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << MultiCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << MultiCmdTimer_STATUS_FIFOFULL_INT_MASK_SHIFT)))
#endif /* (MultiCmdTimer_UsingFixedFunction) */
#define MultiCmdTimer_INIT_CAPTURE_COUNT      (2u)
#define MultiCmdTimer_INIT_INT_CAPTURE_COUNT  ((uint8)((uint8)(1u - 1u) << MultiCmdTimer_CTRL_INTCNT_SHIFT))


/***************************************
*           Registers
***************************************/

#if (MultiCmdTimer_UsingFixedFunction) /* Implementation Specific Registers and Register Constants */


    /***************************************
    *    Fixed Function Registers
    ***************************************/

    #define MultiCmdTimer_STATUS         (*(reg8 *) MultiCmdTimer_TimerHW__SR0 )
    /* In Fixed Function Block Status and Mask are the same register */
    #define MultiCmdTimer_STATUS_MASK    (*(reg8 *) MultiCmdTimer_TimerHW__SR0 )
    #define MultiCmdTimer_CONTROL        (*(reg8 *) MultiCmdTimer_TimerHW__CFG0)
    #define MultiCmdTimer_CONTROL2       (*(reg8 *) MultiCmdTimer_TimerHW__CFG1)
    #define MultiCmdTimer_CONTROL2_PTR   ( (reg8 *) MultiCmdTimer_TimerHW__CFG1)
    #define MultiCmdTimer_RT1            (*(reg8 *) MultiCmdTimer_TimerHW__RT1)
    #define MultiCmdTimer_RT1_PTR        ( (reg8 *) MultiCmdTimer_TimerHW__RT1)

    #if (CY_PSOC3 || CY_PSOC5LP)
        #define MultiCmdTimer_CONTROL3       (*(reg8 *) MultiCmdTimer_TimerHW__CFG2)
        #define MultiCmdTimer_CONTROL3_PTR   ( (reg8 *) MultiCmdTimer_TimerHW__CFG2)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    #define MultiCmdTimer_GLOBAL_ENABLE  (*(reg8 *) MultiCmdTimer_TimerHW__PM_ACT_CFG)
    #define MultiCmdTimer_GLOBAL_STBY_ENABLE  (*(reg8 *) MultiCmdTimer_TimerHW__PM_STBY_CFG)

    #define MultiCmdTimer_CAPTURE_LSB         (* (reg16 *) MultiCmdTimer_TimerHW__CAP0 )
    #define MultiCmdTimer_CAPTURE_LSB_PTR       ((reg16 *) MultiCmdTimer_TimerHW__CAP0 )
    #define MultiCmdTimer_PERIOD_LSB          (* (reg16 *) MultiCmdTimer_TimerHW__PER0 )
    #define MultiCmdTimer_PERIOD_LSB_PTR        ((reg16 *) MultiCmdTimer_TimerHW__PER0 )
    #define MultiCmdTimer_COUNTER_LSB         (* (reg16 *) MultiCmdTimer_TimerHW__CNT_CMP0 )
    #define MultiCmdTimer_COUNTER_LSB_PTR       ((reg16 *) MultiCmdTimer_TimerHW__CNT_CMP0 )


    /***************************************
    *    Register Constants
    ***************************************/

    /* Fixed Function Block Chosen */
    #define MultiCmdTimer_BLOCK_EN_MASK                     MultiCmdTimer_TimerHW__PM_ACT_MSK
    #define MultiCmdTimer_BLOCK_STBY_EN_MASK                MultiCmdTimer_TimerHW__PM_STBY_MSK

    /* Control Register Bit Locations */
    /* Interrupt Count - Not valid for Fixed Function Block */
    #define MultiCmdTimer_CTRL_INTCNT_SHIFT                  0x00u
    /* Trigger Polarity - Not valid for Fixed Function Block */
    #define MultiCmdTimer_CTRL_TRIG_MODE_SHIFT               0x00u
    /* Trigger Enable - Not valid for Fixed Function Block */
    #define MultiCmdTimer_CTRL_TRIG_EN_SHIFT                 0x00u
    /* Capture Polarity - Not valid for Fixed Function Block */
    #define MultiCmdTimer_CTRL_CAP_MODE_SHIFT                0x00u
    /* Timer Enable - As defined in Register Map, part of TMRX_CFG0 register */
    #define MultiCmdTimer_CTRL_ENABLE_SHIFT                  0x00u

    /* Control Register Bit Masks */
    #define MultiCmdTimer_CTRL_ENABLE                        ((uint8)((uint8)0x01u << MultiCmdTimer_CTRL_ENABLE_SHIFT))

    /* Control2 Register Bit Masks */
    /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define MultiCmdTimer_CTRL2_IRQ_SEL_SHIFT                 0x00u
    #define MultiCmdTimer_CTRL2_IRQ_SEL                      ((uint8)((uint8)0x01u << MultiCmdTimer_CTRL2_IRQ_SEL_SHIFT))

    #if (CY_PSOC5A)
        /* Use CFG1 Mode bits to set run mode */
        /* As defined by Verilog Implementation */
        #define MultiCmdTimer_CTRL_MODE_SHIFT                 0x01u
        #define MultiCmdTimer_CTRL_MODE_MASK                 ((uint8)((uint8)0x07u << MultiCmdTimer_CTRL_MODE_SHIFT))
    #endif /* (CY_PSOC5A) */
    #if (CY_PSOC3 || CY_PSOC5LP)
        /* Control3 Register Bit Locations */
        #define MultiCmdTimer_CTRL_RCOD_SHIFT        0x02u
        #define MultiCmdTimer_CTRL_ENBL_SHIFT        0x00u
        #define MultiCmdTimer_CTRL_MODE_SHIFT        0x00u

        /* Control3 Register Bit Masks */
        #define MultiCmdTimer_CTRL_RCOD_MASK  ((uint8)((uint8)0x03u << MultiCmdTimer_CTRL_RCOD_SHIFT)) /* ROD and COD bit masks */
        #define MultiCmdTimer_CTRL_ENBL_MASK  ((uint8)((uint8)0x80u << MultiCmdTimer_CTRL_ENBL_SHIFT)) /* HW_EN bit mask */
        #define MultiCmdTimer_CTRL_MODE_MASK  ((uint8)((uint8)0x03u << MultiCmdTimer_CTRL_MODE_SHIFT)) /* Run mode bit mask */

        #define MultiCmdTimer_CTRL_RCOD       ((uint8)((uint8)0x03u << MultiCmdTimer_CTRL_RCOD_SHIFT))
        #define MultiCmdTimer_CTRL_ENBL       ((uint8)((uint8)0x80u << MultiCmdTimer_CTRL_ENBL_SHIFT))
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */

    /*RT1 Synch Constants: Applicable for PSoC3 and PSoC5LP */
    #define MultiCmdTimer_RT1_SHIFT                       0x04u
    /* Sync TC and CMP bit masks */
    #define MultiCmdTimer_RT1_MASK                        ((uint8)((uint8)0x03u << MultiCmdTimer_RT1_SHIFT))
    #define MultiCmdTimer_SYNC                            ((uint8)((uint8)0x03u << MultiCmdTimer_RT1_SHIFT))
    #define MultiCmdTimer_SYNCDSI_SHIFT                   0x00u
    /* Sync all DSI inputs with Mask  */
    #define MultiCmdTimer_SYNCDSI_MASK                    ((uint8)((uint8)0x0Fu << MultiCmdTimer_SYNCDSI_SHIFT))
    /* Sync all DSI inputs */
    #define MultiCmdTimer_SYNCDSI_EN                      ((uint8)((uint8)0x0Fu << MultiCmdTimer_SYNCDSI_SHIFT))

    #define MultiCmdTimer_CTRL_MODE_PULSEWIDTH            ((uint8)((uint8)0x01u << MultiCmdTimer_CTRL_MODE_SHIFT))
    #define MultiCmdTimer_CTRL_MODE_PERIOD                ((uint8)((uint8)0x02u << MultiCmdTimer_CTRL_MODE_SHIFT))
    #define MultiCmdTimer_CTRL_MODE_CONTINUOUS            ((uint8)((uint8)0x00u << MultiCmdTimer_CTRL_MODE_SHIFT))

    /* Status Register Bit Locations */
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define MultiCmdTimer_STATUS_TC_SHIFT                 0x07u
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define MultiCmdTimer_STATUS_CAPTURE_SHIFT            0x06u
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define MultiCmdTimer_STATUS_TC_INT_MASK_SHIFT        (MultiCmdTimer_STATUS_TC_SHIFT - 0x04u)
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define MultiCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT   (MultiCmdTimer_STATUS_CAPTURE_SHIFT - 0x04u)

    /* Status Register Bit Masks */
    #define MultiCmdTimer_STATUS_TC                       ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_TC_SHIFT))
    #define MultiCmdTimer_STATUS_CAPTURE                  ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on TC */
    #define MultiCmdTimer_STATUS_TC_INT_MASK              ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_TC_INT_MASK_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on Capture */
    #define MultiCmdTimer_STATUS_CAPTURE_INT_MASK         ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT))

#else   /* UDB Registers and Register Constants */


    /***************************************
    *           UDB Registers
    ***************************************/

    #define MultiCmdTimer_STATUS              (* (reg8 *) MultiCmdTimer_TimerUDB_rstSts_stsreg__STATUS_REG )
    #define MultiCmdTimer_STATUS_MASK         (* (reg8 *) MultiCmdTimer_TimerUDB_rstSts_stsreg__MASK_REG)
    #define MultiCmdTimer_STATUS_AUX_CTRL     (* (reg8 *) MultiCmdTimer_TimerUDB_rstSts_stsreg__STATUS_AUX_CTL_REG)
    #define MultiCmdTimer_CONTROL             (* (reg8 *) MultiCmdTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG )
    
    #if(MultiCmdTimer_Resolution <= 8u) /* 8-bit Timer */
        #define MultiCmdTimer_CAPTURE_LSB         (* (reg8 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define MultiCmdTimer_CAPTURE_LSB_PTR       ((reg8 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define MultiCmdTimer_PERIOD_LSB          (* (reg8 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define MultiCmdTimer_PERIOD_LSB_PTR        ((reg8 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define MultiCmdTimer_COUNTER_LSB         (* (reg8 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #define MultiCmdTimer_COUNTER_LSB_PTR       ((reg8 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
    #elif(MultiCmdTimer_Resolution <= 16u) /* 8-bit Timer */
        #if(CY_PSOC3) /* 8-bit addres space */
            #define MultiCmdTimer_CAPTURE_LSB         (* (reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define MultiCmdTimer_CAPTURE_LSB_PTR       ((reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define MultiCmdTimer_PERIOD_LSB          (* (reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define MultiCmdTimer_PERIOD_LSB_PTR        ((reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define MultiCmdTimer_COUNTER_LSB         (* (reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
            #define MultiCmdTimer_COUNTER_LSB_PTR       ((reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #else /* 16-bit address space */
            #define MultiCmdTimer_CAPTURE_LSB         (* (reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__16BIT_F0_REG )
            #define MultiCmdTimer_CAPTURE_LSB_PTR       ((reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__16BIT_F0_REG )
            #define MultiCmdTimer_PERIOD_LSB          (* (reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__16BIT_D0_REG )
            #define MultiCmdTimer_PERIOD_LSB_PTR        ((reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__16BIT_D0_REG )
            #define MultiCmdTimer_COUNTER_LSB         (* (reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__16BIT_A0_REG )
            #define MultiCmdTimer_COUNTER_LSB_PTR       ((reg16 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__16BIT_A0_REG )
        #endif /* CY_PSOC3 */
    #elif(MultiCmdTimer_Resolution <= 24u)/* 24-bit Timer */
        #define MultiCmdTimer_CAPTURE_LSB         (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define MultiCmdTimer_CAPTURE_LSB_PTR       ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define MultiCmdTimer_PERIOD_LSB          (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define MultiCmdTimer_PERIOD_LSB_PTR        ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define MultiCmdTimer_COUNTER_LSB         (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #define MultiCmdTimer_COUNTER_LSB_PTR       ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
    #else /* 32-bit Timer */
        #if(CY_PSOC3 || CY_PSOC5) /* 8-bit address space */
            #define MultiCmdTimer_CAPTURE_LSB         (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define MultiCmdTimer_CAPTURE_LSB_PTR       ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define MultiCmdTimer_PERIOD_LSB          (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define MultiCmdTimer_PERIOD_LSB_PTR        ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define MultiCmdTimer_COUNTER_LSB         (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
            #define MultiCmdTimer_COUNTER_LSB_PTR       ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #else /* 32-bit address space */
            #define MultiCmdTimer_CAPTURE_LSB         (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__32BIT_F0_REG )
            #define MultiCmdTimer_CAPTURE_LSB_PTR       ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__32BIT_F0_REG )
            #define MultiCmdTimer_PERIOD_LSB          (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__32BIT_D0_REG )
            #define MultiCmdTimer_PERIOD_LSB_PTR        ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__32BIT_D0_REG )
            #define MultiCmdTimer_COUNTER_LSB         (* (reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__32BIT_A0_REG )
            #define MultiCmdTimer_COUNTER_LSB_PTR       ((reg32 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__32BIT_A0_REG )
        #endif /* CY_PSOC3 || CY_PSOC5 */ 
    #endif

    #define MultiCmdTimer_COUNTER_LSB_PTR_8BIT       ((reg8 *) MultiCmdTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
    
    #if (MultiCmdTimer_UsingHWCaptureCounter)
        #define MultiCmdTimer_CAP_COUNT              (*(reg8 *) MultiCmdTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define MultiCmdTimer_CAP_COUNT_PTR          ( (reg8 *) MultiCmdTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define MultiCmdTimer_CAPTURE_COUNT_CTRL     (*(reg8 *) MultiCmdTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
        #define MultiCmdTimer_CAPTURE_COUNT_CTRL_PTR ( (reg8 *) MultiCmdTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
    #endif /* (MultiCmdTimer_UsingHWCaptureCounter) */


    /***************************************
    *       Register Constants
    ***************************************/

    /* Control Register Bit Locations */
    #define MultiCmdTimer_CTRL_INTCNT_SHIFT              0x00u       /* As defined by Verilog Implementation */
    #define MultiCmdTimer_CTRL_TRIG_MODE_SHIFT           0x02u       /* As defined by Verilog Implementation */
    #define MultiCmdTimer_CTRL_TRIG_EN_SHIFT             0x04u       /* As defined by Verilog Implementation */
    #define MultiCmdTimer_CTRL_CAP_MODE_SHIFT            0x05u       /* As defined by Verilog Implementation */
    #define MultiCmdTimer_CTRL_ENABLE_SHIFT              0x07u       /* As defined by Verilog Implementation */

    /* Control Register Bit Masks */
    #define MultiCmdTimer_CTRL_INTCNT_MASK               ((uint8)((uint8)0x03u << MultiCmdTimer_CTRL_INTCNT_SHIFT))
    #define MultiCmdTimer_CTRL_TRIG_MODE_MASK            ((uint8)((uint8)0x03u << MultiCmdTimer_CTRL_TRIG_MODE_SHIFT))
    #define MultiCmdTimer_CTRL_TRIG_EN                   ((uint8)((uint8)0x01u << MultiCmdTimer_CTRL_TRIG_EN_SHIFT))
    #define MultiCmdTimer_CTRL_CAP_MODE_MASK             ((uint8)((uint8)0x03u << MultiCmdTimer_CTRL_CAP_MODE_SHIFT))
    #define MultiCmdTimer_CTRL_ENABLE                    ((uint8)((uint8)0x01u << MultiCmdTimer_CTRL_ENABLE_SHIFT))

    /* Bit Counter (7-bit) Control Register Bit Definitions */
    /* As defined by the Register map for the AUX Control Register */
    #define MultiCmdTimer_CNTR_ENABLE                    0x20u

    /* Status Register Bit Locations */
    #define MultiCmdTimer_STATUS_TC_SHIFT                0x00u  /* As defined by Verilog Implementation */
    #define MultiCmdTimer_STATUS_CAPTURE_SHIFT           0x01u  /* As defined by Verilog Implementation */
    #define MultiCmdTimer_STATUS_TC_INT_MASK_SHIFT       MultiCmdTimer_STATUS_TC_SHIFT
    #define MultiCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT  MultiCmdTimer_STATUS_CAPTURE_SHIFT
    #define MultiCmdTimer_STATUS_FIFOFULL_SHIFT          0x02u  /* As defined by Verilog Implementation */
    #define MultiCmdTimer_STATUS_FIFONEMP_SHIFT          0x03u  /* As defined by Verilog Implementation */
    #define MultiCmdTimer_STATUS_FIFOFULL_INT_MASK_SHIFT MultiCmdTimer_STATUS_FIFOFULL_SHIFT

    /* Status Register Bit Masks */
    /* Sticky TC Event Bit-Mask */
    #define MultiCmdTimer_STATUS_TC                      ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_TC_SHIFT))
    /* Sticky Capture Event Bit-Mask */
    #define MultiCmdTimer_STATUS_CAPTURE                 ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define MultiCmdTimer_STATUS_TC_INT_MASK             ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_TC_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define MultiCmdTimer_STATUS_CAPTURE_INT_MASK        ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_CAPTURE_SHIFT))
    /* NOT-Sticky FIFO Full Bit-Mask */
    #define MultiCmdTimer_STATUS_FIFOFULL                ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_FIFOFULL_SHIFT))
    /* NOT-Sticky FIFO Not Empty Bit-Mask */
    #define MultiCmdTimer_STATUS_FIFONEMP                ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_FIFONEMP_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define MultiCmdTimer_STATUS_FIFOFULL_INT_MASK       ((uint8)((uint8)0x01u << MultiCmdTimer_STATUS_FIFOFULL_SHIFT))

    #define MultiCmdTimer_STATUS_ACTL_INT_EN             0x10u   /* As defined for the ACTL Register */

    /* Datapath Auxillary Control Register definitions */
    #define MultiCmdTimer_AUX_CTRL_FIFO0_CLR             0x01u   /* As defined by Register map */
    #define MultiCmdTimer_AUX_CTRL_FIFO1_CLR             0x02u   /* As defined by Register map */
    #define MultiCmdTimer_AUX_CTRL_FIFO0_LVL             0x04u   /* As defined by Register map */
    #define MultiCmdTimer_AUX_CTRL_FIFO1_LVL             0x08u   /* As defined by Register map */
    #define MultiCmdTimer_STATUS_ACTL_INT_EN_MASK        0x10u   /* As defined for the ACTL Register */

#endif /* Implementation Specific Registers and Register Constants */

#endif  /* CY_TIMER_MultiCmdTimer_H */


/* [] END OF FILE */
