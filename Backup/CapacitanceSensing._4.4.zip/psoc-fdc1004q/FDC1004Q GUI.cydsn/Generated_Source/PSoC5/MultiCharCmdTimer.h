/*******************************************************************************
* File Name: MultiCharCmdTimer.h
* Version 2.80
*
*  Description:
*     Contains the function prototypes and constants available to the timer
*     user module.
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_TIMER_MultiCharCmdTimer_H)
#define CY_TIMER_MultiCharCmdTimer_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

extern uint8 MultiCharCmdTimer_initVar;

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component Timer_v2_80 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */


/**************************************
*           Parameter Defaults
**************************************/

#define MultiCharCmdTimer_Resolution                 16u
#define MultiCharCmdTimer_UsingFixedFunction         1u
#define MultiCharCmdTimer_UsingHWCaptureCounter      0u
#define MultiCharCmdTimer_SoftwareCaptureMode        0u
#define MultiCharCmdTimer_SoftwareTriggerMode        0u
#define MultiCharCmdTimer_UsingHWEnable              0u
#define MultiCharCmdTimer_EnableTriggerMode          0u
#define MultiCharCmdTimer_InterruptOnCaptureCount    0u
#define MultiCharCmdTimer_RunModeUsed                0u
#define MultiCharCmdTimer_ControlRegRemoved          0u

#if defined(MultiCharCmdTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG)
    #define MultiCharCmdTimer_UDB_CONTROL_REG_REMOVED            (0u)
#elif  (MultiCharCmdTimer_UsingFixedFunction)
    #define MultiCharCmdTimer_UDB_CONTROL_REG_REMOVED            (0u)
#else 
    #define MultiCharCmdTimer_UDB_CONTROL_REG_REMOVED            (1u)
#endif /* End MultiCharCmdTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG */


/***************************************
*       Type defines
***************************************/


/**************************************************************************
 * Sleep Wakeup Backup structure for Timer Component
 *************************************************************************/
typedef struct
{
    uint8 TimerEnableState;
    #if(!MultiCharCmdTimer_UsingFixedFunction)

        uint16 TimerUdb;
        uint8 InterruptMaskValue;
        #if (MultiCharCmdTimer_UsingHWCaptureCounter)
            uint8 TimerCaptureCounter;
        #endif /* variable declarations for backing up non retention registers in CY_UDB_V1 */

        #if (!MultiCharCmdTimer_UDB_CONTROL_REG_REMOVED)
            uint8 TimerControlRegister;
        #endif /* variable declaration for backing up enable state of the Timer */
    #endif /* define backup variables only for UDB implementation. Fixed function registers are all retention */

}MultiCharCmdTimer_backupStruct;


/***************************************
*       Function Prototypes
***************************************/

void    MultiCharCmdTimer_Start(void) ;
void    MultiCharCmdTimer_Stop(void) ;

void    MultiCharCmdTimer_SetInterruptMode(uint8 interruptMode) ;
uint8   MultiCharCmdTimer_ReadStatusRegister(void) ;
/* Deprecated function. Do not use this in future. Retained for backward compatibility */
#define MultiCharCmdTimer_GetInterruptSource() MultiCharCmdTimer_ReadStatusRegister()

#if(!MultiCharCmdTimer_UDB_CONTROL_REG_REMOVED)
    uint8   MultiCharCmdTimer_ReadControlRegister(void) ;
    void    MultiCharCmdTimer_WriteControlRegister(uint8 control) ;
#endif /* (!MultiCharCmdTimer_UDB_CONTROL_REG_REMOVED) */

uint16  MultiCharCmdTimer_ReadPeriod(void) ;
void    MultiCharCmdTimer_WritePeriod(uint16 period) ;
uint16  MultiCharCmdTimer_ReadCounter(void) ;
void    MultiCharCmdTimer_WriteCounter(uint16 counter) ;
uint16  MultiCharCmdTimer_ReadCapture(void) ;
void    MultiCharCmdTimer_SoftwareCapture(void) ;

#if(!MultiCharCmdTimer_UsingFixedFunction) /* UDB Prototypes */
    #if (MultiCharCmdTimer_SoftwareCaptureMode)
        void    MultiCharCmdTimer_SetCaptureMode(uint8 captureMode) ;
    #endif /* (!MultiCharCmdTimer_UsingFixedFunction) */

    #if (MultiCharCmdTimer_SoftwareTriggerMode)
        void    MultiCharCmdTimer_SetTriggerMode(uint8 triggerMode) ;
    #endif /* (MultiCharCmdTimer_SoftwareTriggerMode) */

    #if (MultiCharCmdTimer_EnableTriggerMode)
        void    MultiCharCmdTimer_EnableTrigger(void) ;
        void    MultiCharCmdTimer_DisableTrigger(void) ;
    #endif /* (MultiCharCmdTimer_EnableTriggerMode) */


    #if(MultiCharCmdTimer_InterruptOnCaptureCount)
        void    MultiCharCmdTimer_SetInterruptCount(uint8 interruptCount) ;
    #endif /* (MultiCharCmdTimer_InterruptOnCaptureCount) */

    #if (MultiCharCmdTimer_UsingHWCaptureCounter)
        void    MultiCharCmdTimer_SetCaptureCount(uint8 captureCount) ;
        uint8   MultiCharCmdTimer_ReadCaptureCount(void) ;
    #endif /* (MultiCharCmdTimer_UsingHWCaptureCounter) */

    void MultiCharCmdTimer_ClearFIFO(void) ;
#endif /* UDB Prototypes */

/* Sleep Retention APIs */
void MultiCharCmdTimer_Init(void)          ;
void MultiCharCmdTimer_Enable(void)        ;
void MultiCharCmdTimer_SaveConfig(void)    ;
void MultiCharCmdTimer_RestoreConfig(void) ;
void MultiCharCmdTimer_Sleep(void)         ;
void MultiCharCmdTimer_Wakeup(void)        ;


/***************************************
*   Enumerated Types and Parameters
***************************************/

/* Enumerated Type B_Timer__CaptureModes, Used in Capture Mode */
#define MultiCharCmdTimer__B_TIMER__CM_NONE 0
#define MultiCharCmdTimer__B_TIMER__CM_RISINGEDGE 1
#define MultiCharCmdTimer__B_TIMER__CM_FALLINGEDGE 2
#define MultiCharCmdTimer__B_TIMER__CM_EITHEREDGE 3
#define MultiCharCmdTimer__B_TIMER__CM_SOFTWARE 4



/* Enumerated Type B_Timer__TriggerModes, Used in Trigger Mode */
#define MultiCharCmdTimer__B_TIMER__TM_NONE 0x00u
#define MultiCharCmdTimer__B_TIMER__TM_RISINGEDGE 0x04u
#define MultiCharCmdTimer__B_TIMER__TM_FALLINGEDGE 0x08u
#define MultiCharCmdTimer__B_TIMER__TM_EITHEREDGE 0x0Cu
#define MultiCharCmdTimer__B_TIMER__TM_SOFTWARE 0x10u


/***************************************
*    Initialial Parameter Constants
***************************************/

#define MultiCharCmdTimer_INIT_PERIOD             65535u
#define MultiCharCmdTimer_INIT_CAPTURE_MODE       ((uint8)((uint8)1u << MultiCharCmdTimer_CTRL_CAP_MODE_SHIFT))
#define MultiCharCmdTimer_INIT_TRIGGER_MODE       ((uint8)((uint8)0u << MultiCharCmdTimer_CTRL_TRIG_MODE_SHIFT))
#if (MultiCharCmdTimer_UsingFixedFunction)
    #define MultiCharCmdTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)0u << MultiCharCmdTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                  ((uint8)((uint8)0 << MultiCharCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT)))
#else
    #define MultiCharCmdTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)0u << MultiCharCmdTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << MultiCharCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << MultiCharCmdTimer_STATUS_FIFOFULL_INT_MASK_SHIFT)))
#endif /* (MultiCharCmdTimer_UsingFixedFunction) */
#define MultiCharCmdTimer_INIT_CAPTURE_COUNT      (2u)
#define MultiCharCmdTimer_INIT_INT_CAPTURE_COUNT  ((uint8)((uint8)(1u - 1u) << MultiCharCmdTimer_CTRL_INTCNT_SHIFT))


/***************************************
*           Registers
***************************************/

#if (MultiCharCmdTimer_UsingFixedFunction) /* Implementation Specific Registers and Register Constants */


    /***************************************
    *    Fixed Function Registers
    ***************************************/

    #define MultiCharCmdTimer_STATUS         (*(reg8 *) MultiCharCmdTimer_TimerHW__SR0 )
    /* In Fixed Function Block Status and Mask are the same register */
    #define MultiCharCmdTimer_STATUS_MASK    (*(reg8 *) MultiCharCmdTimer_TimerHW__SR0 )
    #define MultiCharCmdTimer_CONTROL        (*(reg8 *) MultiCharCmdTimer_TimerHW__CFG0)
    #define MultiCharCmdTimer_CONTROL2       (*(reg8 *) MultiCharCmdTimer_TimerHW__CFG1)
    #define MultiCharCmdTimer_CONTROL2_PTR   ( (reg8 *) MultiCharCmdTimer_TimerHW__CFG1)
    #define MultiCharCmdTimer_RT1            (*(reg8 *) MultiCharCmdTimer_TimerHW__RT1)
    #define MultiCharCmdTimer_RT1_PTR        ( (reg8 *) MultiCharCmdTimer_TimerHW__RT1)

    #if (CY_PSOC3 || CY_PSOC5LP)
        #define MultiCharCmdTimer_CONTROL3       (*(reg8 *) MultiCharCmdTimer_TimerHW__CFG2)
        #define MultiCharCmdTimer_CONTROL3_PTR   ( (reg8 *) MultiCharCmdTimer_TimerHW__CFG2)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    #define MultiCharCmdTimer_GLOBAL_ENABLE  (*(reg8 *) MultiCharCmdTimer_TimerHW__PM_ACT_CFG)
    #define MultiCharCmdTimer_GLOBAL_STBY_ENABLE  (*(reg8 *) MultiCharCmdTimer_TimerHW__PM_STBY_CFG)

    #define MultiCharCmdTimer_CAPTURE_LSB         (* (reg16 *) MultiCharCmdTimer_TimerHW__CAP0 )
    #define MultiCharCmdTimer_CAPTURE_LSB_PTR       ((reg16 *) MultiCharCmdTimer_TimerHW__CAP0 )
    #define MultiCharCmdTimer_PERIOD_LSB          (* (reg16 *) MultiCharCmdTimer_TimerHW__PER0 )
    #define MultiCharCmdTimer_PERIOD_LSB_PTR        ((reg16 *) MultiCharCmdTimer_TimerHW__PER0 )
    #define MultiCharCmdTimer_COUNTER_LSB         (* (reg16 *) MultiCharCmdTimer_TimerHW__CNT_CMP0 )
    #define MultiCharCmdTimer_COUNTER_LSB_PTR       ((reg16 *) MultiCharCmdTimer_TimerHW__CNT_CMP0 )


    /***************************************
    *    Register Constants
    ***************************************/

    /* Fixed Function Block Chosen */
    #define MultiCharCmdTimer_BLOCK_EN_MASK                     MultiCharCmdTimer_TimerHW__PM_ACT_MSK
    #define MultiCharCmdTimer_BLOCK_STBY_EN_MASK                MultiCharCmdTimer_TimerHW__PM_STBY_MSK

    /* Control Register Bit Locations */
    /* Interrupt Count - Not valid for Fixed Function Block */
    #define MultiCharCmdTimer_CTRL_INTCNT_SHIFT                  0x00u
    /* Trigger Polarity - Not valid for Fixed Function Block */
    #define MultiCharCmdTimer_CTRL_TRIG_MODE_SHIFT               0x00u
    /* Trigger Enable - Not valid for Fixed Function Block */
    #define MultiCharCmdTimer_CTRL_TRIG_EN_SHIFT                 0x00u
    /* Capture Polarity - Not valid for Fixed Function Block */
    #define MultiCharCmdTimer_CTRL_CAP_MODE_SHIFT                0x00u
    /* Timer Enable - As defined in Register Map, part of TMRX_CFG0 register */
    #define MultiCharCmdTimer_CTRL_ENABLE_SHIFT                  0x00u

    /* Control Register Bit Masks */
    #define MultiCharCmdTimer_CTRL_ENABLE                        ((uint8)((uint8)0x01u << MultiCharCmdTimer_CTRL_ENABLE_SHIFT))

    /* Control2 Register Bit Masks */
    /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define MultiCharCmdTimer_CTRL2_IRQ_SEL_SHIFT                 0x00u
    #define MultiCharCmdTimer_CTRL2_IRQ_SEL                      ((uint8)((uint8)0x01u << MultiCharCmdTimer_CTRL2_IRQ_SEL_SHIFT))

    #if (CY_PSOC5A)
        /* Use CFG1 Mode bits to set run mode */
        /* As defined by Verilog Implementation */
        #define MultiCharCmdTimer_CTRL_MODE_SHIFT                 0x01u
        #define MultiCharCmdTimer_CTRL_MODE_MASK                 ((uint8)((uint8)0x07u << MultiCharCmdTimer_CTRL_MODE_SHIFT))
    #endif /* (CY_PSOC5A) */
    #if (CY_PSOC3 || CY_PSOC5LP)
        /* Control3 Register Bit Locations */
        #define MultiCharCmdTimer_CTRL_RCOD_SHIFT        0x02u
        #define MultiCharCmdTimer_CTRL_ENBL_SHIFT        0x00u
        #define MultiCharCmdTimer_CTRL_MODE_SHIFT        0x00u

        /* Control3 Register Bit Masks */
        #define MultiCharCmdTimer_CTRL_RCOD_MASK  ((uint8)((uint8)0x03u << MultiCharCmdTimer_CTRL_RCOD_SHIFT)) /* ROD and COD bit masks */
        #define MultiCharCmdTimer_CTRL_ENBL_MASK  ((uint8)((uint8)0x80u << MultiCharCmdTimer_CTRL_ENBL_SHIFT)) /* HW_EN bit mask */
        #define MultiCharCmdTimer_CTRL_MODE_MASK  ((uint8)((uint8)0x03u << MultiCharCmdTimer_CTRL_MODE_SHIFT)) /* Run mode bit mask */

        #define MultiCharCmdTimer_CTRL_RCOD       ((uint8)((uint8)0x03u << MultiCharCmdTimer_CTRL_RCOD_SHIFT))
        #define MultiCharCmdTimer_CTRL_ENBL       ((uint8)((uint8)0x80u << MultiCharCmdTimer_CTRL_ENBL_SHIFT))
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */

    /*RT1 Synch Constants: Applicable for PSoC3 and PSoC5LP */
    #define MultiCharCmdTimer_RT1_SHIFT                       0x04u
    /* Sync TC and CMP bit masks */
    #define MultiCharCmdTimer_RT1_MASK                        ((uint8)((uint8)0x03u << MultiCharCmdTimer_RT1_SHIFT))
    #define MultiCharCmdTimer_SYNC                            ((uint8)((uint8)0x03u << MultiCharCmdTimer_RT1_SHIFT))
    #define MultiCharCmdTimer_SYNCDSI_SHIFT                   0x00u
    /* Sync all DSI inputs with Mask  */
    #define MultiCharCmdTimer_SYNCDSI_MASK                    ((uint8)((uint8)0x0Fu << MultiCharCmdTimer_SYNCDSI_SHIFT))
    /* Sync all DSI inputs */
    #define MultiCharCmdTimer_SYNCDSI_EN                      ((uint8)((uint8)0x0Fu << MultiCharCmdTimer_SYNCDSI_SHIFT))

    #define MultiCharCmdTimer_CTRL_MODE_PULSEWIDTH            ((uint8)((uint8)0x01u << MultiCharCmdTimer_CTRL_MODE_SHIFT))
    #define MultiCharCmdTimer_CTRL_MODE_PERIOD                ((uint8)((uint8)0x02u << MultiCharCmdTimer_CTRL_MODE_SHIFT))
    #define MultiCharCmdTimer_CTRL_MODE_CONTINUOUS            ((uint8)((uint8)0x00u << MultiCharCmdTimer_CTRL_MODE_SHIFT))

    /* Status Register Bit Locations */
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define MultiCharCmdTimer_STATUS_TC_SHIFT                 0x07u
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define MultiCharCmdTimer_STATUS_CAPTURE_SHIFT            0x06u
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define MultiCharCmdTimer_STATUS_TC_INT_MASK_SHIFT        (MultiCharCmdTimer_STATUS_TC_SHIFT - 0x04u)
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define MultiCharCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT   (MultiCharCmdTimer_STATUS_CAPTURE_SHIFT - 0x04u)

    /* Status Register Bit Masks */
    #define MultiCharCmdTimer_STATUS_TC                       ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_TC_SHIFT))
    #define MultiCharCmdTimer_STATUS_CAPTURE                  ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on TC */
    #define MultiCharCmdTimer_STATUS_TC_INT_MASK              ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_TC_INT_MASK_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on Capture */
    #define MultiCharCmdTimer_STATUS_CAPTURE_INT_MASK         ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT))

#else   /* UDB Registers and Register Constants */


    /***************************************
    *           UDB Registers
    ***************************************/

    #define MultiCharCmdTimer_STATUS              (* (reg8 *) MultiCharCmdTimer_TimerUDB_rstSts_stsreg__STATUS_REG )
    #define MultiCharCmdTimer_STATUS_MASK         (* (reg8 *) MultiCharCmdTimer_TimerUDB_rstSts_stsreg__MASK_REG)
    #define MultiCharCmdTimer_STATUS_AUX_CTRL     (* (reg8 *) MultiCharCmdTimer_TimerUDB_rstSts_stsreg__STATUS_AUX_CTL_REG)
    #define MultiCharCmdTimer_CONTROL             (* (reg8 *) MultiCharCmdTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG )
    
    #if(MultiCharCmdTimer_Resolution <= 8u) /* 8-bit Timer */
        #define MultiCharCmdTimer_CAPTURE_LSB         (* (reg8 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
        #define MultiCharCmdTimer_CAPTURE_LSB_PTR       ((reg8 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
        #define MultiCharCmdTimer_PERIOD_LSB          (* (reg8 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
        #define MultiCharCmdTimer_PERIOD_LSB_PTR        ((reg8 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
        #define MultiCharCmdTimer_COUNTER_LSB         (* (reg8 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
        #define MultiCharCmdTimer_COUNTER_LSB_PTR       ((reg8 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
    #elif(MultiCharCmdTimer_Resolution <= 16u) /* 8-bit Timer */
        #if(CY_PSOC3) /* 8-bit addres space */
            #define MultiCharCmdTimer_CAPTURE_LSB         (* (reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
            #define MultiCharCmdTimer_CAPTURE_LSB_PTR       ((reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB          (* (reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB_PTR        ((reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB         (* (reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB_PTR       ((reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
        #else /* 16-bit address space */
            #define MultiCharCmdTimer_CAPTURE_LSB         (* (reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__16BIT_F0_REG )
            #define MultiCharCmdTimer_CAPTURE_LSB_PTR       ((reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__16BIT_F0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB          (* (reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__16BIT_D0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB_PTR        ((reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__16BIT_D0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB         (* (reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__16BIT_A0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB_PTR       ((reg16 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__16BIT_A0_REG )
        #endif /* CY_PSOC3 */
    #elif(MultiCharCmdTimer_Resolution <= 24u)/* 24-bit Timer */
        #define MultiCharCmdTimer_CAPTURE_LSB         (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
        #define MultiCharCmdTimer_CAPTURE_LSB_PTR       ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
        #define MultiCharCmdTimer_PERIOD_LSB          (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
        #define MultiCharCmdTimer_PERIOD_LSB_PTR        ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
        #define MultiCharCmdTimer_COUNTER_LSB         (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
        #define MultiCharCmdTimer_COUNTER_LSB_PTR       ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
    #else /* 32-bit Timer */
        #if(CY_PSOC3 || CY_PSOC5) /* 8-bit address space */
            #define MultiCharCmdTimer_CAPTURE_LSB         (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
            #define MultiCharCmdTimer_CAPTURE_LSB_PTR       ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__F0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB          (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB_PTR        ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__D0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB         (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB_PTR       ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
        #else /* 32-bit address space */
            #define MultiCharCmdTimer_CAPTURE_LSB         (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__32BIT_F0_REG )
            #define MultiCharCmdTimer_CAPTURE_LSB_PTR       ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__32BIT_F0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB          (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__32BIT_D0_REG )
            #define MultiCharCmdTimer_PERIOD_LSB_PTR        ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__32BIT_D0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB         (* (reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__32BIT_A0_REG )
            #define MultiCharCmdTimer_COUNTER_LSB_PTR       ((reg32 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__32BIT_A0_REG )
        #endif /* CY_PSOC3 || CY_PSOC5 */ 
    #endif

    #define MultiCharCmdTimer_COUNTER_LSB_PTR_8BIT       ((reg8 *) MultiCharCmdTimer_TimerUDB_sT16_timerdp_u0__A0_REG )
    
    #if (MultiCharCmdTimer_UsingHWCaptureCounter)
        #define MultiCharCmdTimer_CAP_COUNT              (*(reg8 *) MultiCharCmdTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define MultiCharCmdTimer_CAP_COUNT_PTR          ( (reg8 *) MultiCharCmdTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define MultiCharCmdTimer_CAPTURE_COUNT_CTRL     (*(reg8 *) MultiCharCmdTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
        #define MultiCharCmdTimer_CAPTURE_COUNT_CTRL_PTR ( (reg8 *) MultiCharCmdTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
    #endif /* (MultiCharCmdTimer_UsingHWCaptureCounter) */


    /***************************************
    *       Register Constants
    ***************************************/

    /* Control Register Bit Locations */
    #define MultiCharCmdTimer_CTRL_INTCNT_SHIFT              0x00u       /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_CTRL_TRIG_MODE_SHIFT           0x02u       /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_CTRL_TRIG_EN_SHIFT             0x04u       /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_CTRL_CAP_MODE_SHIFT            0x05u       /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_CTRL_ENABLE_SHIFT              0x07u       /* As defined by Verilog Implementation */

    /* Control Register Bit Masks */
    #define MultiCharCmdTimer_CTRL_INTCNT_MASK               ((uint8)((uint8)0x03u << MultiCharCmdTimer_CTRL_INTCNT_SHIFT))
    #define MultiCharCmdTimer_CTRL_TRIG_MODE_MASK            ((uint8)((uint8)0x03u << MultiCharCmdTimer_CTRL_TRIG_MODE_SHIFT))
    #define MultiCharCmdTimer_CTRL_TRIG_EN                   ((uint8)((uint8)0x01u << MultiCharCmdTimer_CTRL_TRIG_EN_SHIFT))
    #define MultiCharCmdTimer_CTRL_CAP_MODE_MASK             ((uint8)((uint8)0x03u << MultiCharCmdTimer_CTRL_CAP_MODE_SHIFT))
    #define MultiCharCmdTimer_CTRL_ENABLE                    ((uint8)((uint8)0x01u << MultiCharCmdTimer_CTRL_ENABLE_SHIFT))

    /* Bit Counter (7-bit) Control Register Bit Definitions */
    /* As defined by the Register map for the AUX Control Register */
    #define MultiCharCmdTimer_CNTR_ENABLE                    0x20u

    /* Status Register Bit Locations */
    #define MultiCharCmdTimer_STATUS_TC_SHIFT                0x00u  /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_STATUS_CAPTURE_SHIFT           0x01u  /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_STATUS_TC_INT_MASK_SHIFT       MultiCharCmdTimer_STATUS_TC_SHIFT
    #define MultiCharCmdTimer_STATUS_CAPTURE_INT_MASK_SHIFT  MultiCharCmdTimer_STATUS_CAPTURE_SHIFT
    #define MultiCharCmdTimer_STATUS_FIFOFULL_SHIFT          0x02u  /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_STATUS_FIFONEMP_SHIFT          0x03u  /* As defined by Verilog Implementation */
    #define MultiCharCmdTimer_STATUS_FIFOFULL_INT_MASK_SHIFT MultiCharCmdTimer_STATUS_FIFOFULL_SHIFT

    /* Status Register Bit Masks */
    /* Sticky TC Event Bit-Mask */
    #define MultiCharCmdTimer_STATUS_TC                      ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_TC_SHIFT))
    /* Sticky Capture Event Bit-Mask */
    #define MultiCharCmdTimer_STATUS_CAPTURE                 ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define MultiCharCmdTimer_STATUS_TC_INT_MASK             ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_TC_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define MultiCharCmdTimer_STATUS_CAPTURE_INT_MASK        ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_CAPTURE_SHIFT))
    /* NOT-Sticky FIFO Full Bit-Mask */
    #define MultiCharCmdTimer_STATUS_FIFOFULL                ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_FIFOFULL_SHIFT))
    /* NOT-Sticky FIFO Not Empty Bit-Mask */
    #define MultiCharCmdTimer_STATUS_FIFONEMP                ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_FIFONEMP_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define MultiCharCmdTimer_STATUS_FIFOFULL_INT_MASK       ((uint8)((uint8)0x01u << MultiCharCmdTimer_STATUS_FIFOFULL_SHIFT))

    #define MultiCharCmdTimer_STATUS_ACTL_INT_EN             0x10u   /* As defined for the ACTL Register */

    /* Datapath Auxillary Control Register definitions */
    #define MultiCharCmdTimer_AUX_CTRL_FIFO0_CLR             0x01u   /* As defined by Register map */
    #define MultiCharCmdTimer_AUX_CTRL_FIFO1_CLR             0x02u   /* As defined by Register map */
    #define MultiCharCmdTimer_AUX_CTRL_FIFO0_LVL             0x04u   /* As defined by Register map */
    #define MultiCharCmdTimer_AUX_CTRL_FIFO1_LVL             0x08u   /* As defined by Register map */
    #define MultiCharCmdTimer_STATUS_ACTL_INT_EN_MASK        0x10u   /* As defined for the ACTL Register */

#endif /* Implementation Specific Registers and Register Constants */

#endif  /* CY_TIMER_MultiCharCmdTimer_H */


/* [] END OF FILE */
